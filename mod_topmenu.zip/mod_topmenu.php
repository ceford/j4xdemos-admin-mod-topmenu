<?php
/**
 * @package     Joomla.Administrator
 * @subpackage  mod_menu
 *
 * @copyright   Copyright (C) 2005 - 2019 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

use Joomla\CMS\Helper\ModuleHelper;
use Joomla\Module\Topmenu\Administrator\Topmenu\CssTopmenu;

$enabled = !$app->input->getBool('hidemainmenu');
if ($enabled) {
	$menu = new CssTopmenu($app);
	$root = $menu->load($params, $enabled);
	$root->level = 0;

	// Render the module layout
	require ModuleHelper::getLayoutPath('mod_topmenu', $params->get('layout', 'default'));
}
// else the top menu is not rendered!
