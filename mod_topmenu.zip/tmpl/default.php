<?php
/**
 * @package     Joomla.Administrator
 * @subpackage  mod_menu
 *
 * @copyright   Copyright (C) 2005 - 2019 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

use Joomla\CMS\Helper\ModuleHelper;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;

$doc       = $app->getDocument();
$doc->addStyleSheet(JURI::root(true) . '/administrator/modules/mod_topmenu/smartmenus-1.1.0/css/sm-blue/sm-blue.css');

$doc->addScript(JURI::root(true) . '/administrator/modules/mod_topmenu/smartmenus-1.1.0/jquery.smartmenus.js');
$doc->addScript(JURI::root(true) . '/administrator/modules/mod_topmenu/smartmenus-1.1.0/addons/bootstrap-4/jquery.smartmenus.bootstrap-4.js');
$doc->addScript(JURI::root(true) . '/administrator/modules/mod_topmenu/smartmenus-1.1.0/addons/keyboard/jquery.smartmenus.keyboard.min.js');

?>
<?php if (false): ?>
<nav class="navbar navbar-expand-md navbar-inverse" style="z-index:2000; overflow: visible;">
	<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#topmenu"
		aria-controls="topmenu" aria-expanded="false" aria-label="Toggle navigation">
		<span class="fas fa-bars"></span>
	</button>
	<div class="collapse navbar-collapse" id="topmenu">

		<ul class="nav navbar-nav mr-auto">
			<li>
				<a class="nav-link dropdown"  href="index.php">
				<span class="fa fa-home fa-fw" aria-hidden="true"></span>
				<span class="sidebar-item-title">Home Dashboard</span>
				</a>
			</li>
			<li class="item-100 active deeper dropdown parent text-nowrap">
				<a class="nav-link dropdown has-arrow"  href="#">
					<span class="fa fa-file-alt fa-fw" aria-hidden="true"></span>
					<span class="sidebar-item-title">Content</span>
				</a>
				<ul id="collapse1" class="dropdown-menu">
					<li>
						<span class="nav-link dropdown">
							<a href="/j4/administrator/index.php?option=com_cpanel&view=cpanel&dashboard=content">
								<span class="fa fa-th-large" title="<?php echo Text::_('JLIB_MENUS_PRESET_CONTENT'); ?>" aria-hidden="true"></span>
								<?php echo Text::_('JLIB_MENUS_PRESET_CONTENT'); ?>
								<span class="sr-only"><?php echo Text::_('JLIB_MENUS_PRESET_CONTENT'); ?></span>
							</a>
						</span>
					</li>

					<li><a class="nav-link dropdown"  href="index.php?option=com_content&view=articles"><span class="sidebar-item-title">Articles</span></a><span class="menu-quicktask"><a href="index.php?option=com_content&task=article.add"><span class="fa fa-plus" title="Add Article" aria-hidden="true"></span><span class="sr-only">Add Article</span></a></span></li>
					<li><a class="nav-link dropdown"  href="index.php?option=com_categories&view=categories&extension=com_content"><span class="sidebar-item-title">Categories</span></a><span class="menu-quicktask"><a href="index.php?option=com_categories&extension=com_content&task=category.add"><span class="fa fa-plus" title="Add Category" aria-hidden="true"></span><span class="sr-only">Add Category</span></a></span></li>
					<li><a class="nav-link dropdown"  href="index.php?option=com_content&view=featured"><span class="sidebar-item-title">Featured Articles</span></a></li>
					<li><a class="nav-link dropdown"  href="index.php?option=com_workflow&view=workflows&extension=com_content"><span class="sidebar-item-title">Workflows</span></a></li>
					<li class="divider" role="presentation"><span></span></li>
					<li><a class="nav-link dropdown"  href="index.php?option=com_fields&view=fields&context=com_content.article"><span class="sidebar-item-title">Fields</span></a></li>
					<li><a class="nav-link dropdown"  href="index.php?option=com_fields&view=groups&context=com_content.article"><span class="sidebar-item-title">Field Groups</span></a></li>
					<li class="divider" role="presentation"><span></span></li>
					<li><a class="nav-link dropdown"  href="index.php?option=com_media"><span class="sidebar-item-title">Media</span></a></li>
					<li><a class="nav-link dropdown"  href="index.php?option=com_modules&view=modules&client_id=0"><span class="sidebar-item-title">Site Modules</span></a><span class="menu-quicktask"><a href="index.php?option=com_modules&view=select&client_id=0"><span class="fa fa-plus" title="Add Site Module" aria-hidden="true"></span><span class="sr-only">Add Site Module</span></a></span></li>
					<li><a class="nav-link dropdown"  href="index.php?option=com_modules&view=modules&client_id=1"><span class="sidebar-item-title">Administrator Modules</span></a><span class="menu-quicktask"><a href="index.php?option=com_modules&view=select&client_id=1"><span class="fa fa-plus" title="Add Administrator Module" aria-hidden="true"></span><span class="sr-only">Add Administrator Module</span></a></span></li>
				</ul>
			</li>

			<li class="item-100 active deeper dropdown parent">
				<a class="nav-link dropdown has-arrow"  href="#">
					<span class="fa fa-list fa-fw" aria-hidden="true"></span>
					<span class="sidebar-item-title">Menus</span>
				</a>
				<ul id="collapse2" class="dropdown-menu">
					<li>
						<span class="nav-link dropdown">
							<a href="/j4/administrator/index.php?option=com_cpanel&amp;view=cpanel&amp;dashboard=menus">
								<span class="fa fa-th-large" title="<?php echo Text::_('JLIB_MENUS_PRESET_MENUS'); ?>" aria-hidden="true"></span>
								<?php echo Text::_('JLIB_MENUS_PRESET_MENUS'); ?>
								<span class="sr-only"><?php echo Text::_('JLIB_MENUS_PRESET_MENUS'); ?></span>
							</a>
						</span>
					</li>

					<li><a class="nav-link dropdown"  href="index.php?option=com_menus&view=menus"><span class="sidebar-item-title">Manage</span></a></li>
					<li class="divider" role="presentation"><span></span></li>
					<li><a class="nav-link dropdown"  href="index.php?option=com_menus&view=items&menutype="><span class="sidebar-item-title">All Menu Items</span></a></li>
					<li class="menuitem-group" role="presentation"><span class="sidebar-item-title">Site</span></li>
					<li><a class="nav-link dropdown"  href="index.php?option=com_menus&view=items&menutype=mainmenu"><span class="sidebar-item-title">Main Menu </span><span class="home-image icon-featured" aria-hidden="true"></span><span class="sr-only">Default</span></a><span class="menu-quicktask"><a href="index.php?option=com_menus&task=item.add&menutype=mainmenu"><span class="fa fa-plus" title="Add Site Menu Item" aria-hidden="true"></span><span class="sr-only">Add Site Menu Item</span></a></span></li>
				</ul>
			</li>

			<li class="item-100 active deeper dropdown parent">
				<a class="nav-link dropdown has-arrow"  href="#">
					<span class="fa fa-list fa-fw" aria-hidden="true"></span>
					<span class="sidebar-item-title">Cmponents</span>
				</a>
				<ul id="collapse3" class="dropdown-menu">
					<li>
						<span class="nav-link dropdown">
							<a href="/j4/administrator/index.php?option=com_cpanel&amp;view=cpanel&amp;dashboard=components">
								<span class="fa fa-th-large" title="<?php echo Text::_('JLIB_MENUS_PRESET_COMPONENTS'); ?>" aria-hidden="true"></span>
								<?php echo Text::_('JLIB_MENUS_PRESET_COMPONENTS'); ?>
								<span class="sr-only"><?php echo Text::_('JLIB_MENUS_PRESET_COMPONENTS'); ?></span>
							</a>
						</span>
					</li>

					<li class="dropdown-submenu"><a class="nav-link dropdown has-arrow"  href="index.php?option=com_banners"><span class="sidebar-item-title">Banners</span></a>
						<ul id="menu-2" class="dropdown-menu">
							<li><a class="nav-link dropdown"  href="index.php?option=com_banners&view=banners"><span class="sidebar-item-title">Banners</span></a></li>
							<li><a class="nav-link dropdown"  href="index.php?option=com_categories&view=categories&extension=com_banners"><span class="sidebar-item-title">Categories</span></a></li>
							<li><a class="nav-link dropdown"  href="index.php?option=com_banners&view=clients"><span class="sidebar-item-title">Clients</span></a></li>
							<li><a class="nav-link dropdown"  href="index.php?option=com_banners&view=tracks"><span class="sidebar-item-title">Tracks</span></a></li>
						</ul>
					</li>
					<li class="dropdown-submenu"><a class="nav-link dropdown has-arrow"  href="index.php?option=com_contact"><span class="sidebar-item-title">Contacts</span></a>
						<ul id="menu-7" class="dropdown-menu">
							<li><a class="nav-link dropdown"  href="index.php?option=com_contact&view=contacts"><span class="sidebar-item-title">Contacts</span></a></li>
							<li><a class="nav-link dropdown"  href="index.php?option=com_categories&view=categories&extension=com_contact"><span class="sidebar-item-title">Categories</span></a></li>
							<li><a class="nav-link dropdown"  href="index.php?option=com_fields&context=com_contact.contact"><span class="sidebar-item-title">Fields</span></a></li>
							<li><a class="nav-link dropdown"  href="index.php?option=com_fields&view=groups&context=com_contact.contact"><span class="sidebar-item-title">Field Groups</span></a></li>
						</ul>
					</li>
					<li class="dropdown-submenu"><a class="nav-link dropdown has-arrow"  href="index.php?option=com_messages"><span class="sidebar-item-title">Messaging</span></a>
						<ul id="menu-10" class="dropdown-menu">
							<li><a class="nav-link dropdown"  href="index.php?option=com_messages&task=message.add"><span class="sidebar-item-title">New Private Message</span></a></li>
							<li><a class="nav-link dropdown"  href="index.php?option=com_messages&view=messages"><span class="sidebar-item-title">Private Messages</span></a></li>
						</ul>
					</li>
					<li><a class="nav-link dropdown"  href="index.php?option=com_associations&view=associations"><span class="sidebar-item-title">Multilingual Associations</span></a></li>
					<li class="dropdown-submenu"><a class="nav-link dropdown has-arrow"  href="index.php?option=com_newsfeeds"><span class="sidebar-item-title">News Feeds</span></a>
						<ul id="menu-12" class="dropdown-menu">
							<li><a class="nav-link dropdown"  href="index.php?option=com_categories&view=categories&extension=com_newsfeeds"><span class="sidebar-item-title">Categories</span></a></li>
							<li><a class="nav-link dropdown"  href="index.php?option=com_newsfeeds&view=newsfeeds"><span class="sidebar-item-title">Feeds</span></a></li>
						</ul>
					</li>
					<li><a class="nav-link dropdown"  href="index.php?option=com_sciops"><span class="sidebar-item-title">Sciops</span></a></li>
					<li class="dropdown-submenu"><a class="nav-link dropdown has-arrow"  href="index.php?option=com_sciopssuper"><span class="sidebar-item-title">Sciops Superman</span></a>
						<ul id="menu-102" class="dropdown-menu">
							<li><a class="nav-link dropdown"  href="index.php?option=com_sciopssuper"><span class="sidebar-item-title">Welcome</span></a></li>
							<li><a class="nav-link dropdown"  href="index.php?option=com_sciopssuper&view=branchmanagers"><span class="sidebar-item-title">Branch Managers</span></a></li>
							<li><a class="nav-link dropdown"  href="index.php?option=com_sciopssuper&view=countrymanagers"><span class="sidebar-item-title">Country Managers</span></a></li>
							<li><a class="nav-link dropdown"  href="index.php?option=com_sciopssuper&view=languages"><span class="sidebar-item-title">Languages</span></a></li>
							<li><a class="nav-link dropdown"  href="index.php?option=com_sciopssuper&view=countries"><span class="sidebar-item-title">Countries</span></a></li>
							<li><a class="nav-link dropdown"  href="index.php?option=com_sciopssuper&view=stringkeys"><span class="sidebar-item-title">String Keys</span></a></li>
							<li><a class="nav-link dropdown"  href="index.php?option=com_sciopssuper&view=stringkeysviews"><span class="sidebar-item-title">String Keys-Views Map</span></a></li>
							<li><a class="nav-link dropdown"  href="index.php?option=com_sciopssuper&view=duplicates"><span class="sidebar-item-title">Duplicates</span></a></li>
							<li><a class="nav-link dropdown"  href="index.php?option=com_sciopssuper&view=archive"><span class="sidebar-item-title">Archive</span></a></li>
							<li><a class="nav-link dropdown"  href="index.php?option=com_sciopssuper&view=opsdocs"><span class="sidebar-item-title">Documentation</span></a></li>
						</ul>
					</li>
					<li><a class="nav-link dropdown"  href="index.php?option=com_finder&view=index"><span class="sidebar-item-title">Smart Search</span></a></li>
					<li><a class="nav-link dropdown"  href="index.php?option=com_tags&view=tags"><span class="sidebar-item-title">Tags</span></a></li>
				</ul>
			</li>
			<li class="item-100 active deeper dropdown parent">
				<a class="nav-link dropdown has-arrow"  href="#">
					<span class="fa fa-list fa-fw" aria-hidden="true"></span>
					<span class="sidebar-item-title">Users</span>
				</a>
				<ul id="collapse4" class="dropdown-menu">
					<li>
						<span class="nav-link dropdown">
							<a href="/j4/administrator/index.php?option=com_cpanel&amp;view=cpanel&amp;dashboard=users">
								<span class="fa fa-th-large" title="<?php echo Text::_('JLIB_MENUS_PRESET_USERS'); ?>" aria-hidden="true"></span>
								<?php echo Text::_('JLIB_MENUS_PRESET_USERS'); ?>
								<span class="sr-only"><?php echo Text::_('JLIB_MENUS_PRESET_USERS'); ?></span>
							</a>
						</span>
					</li>
					<li><a class="nav-link dropdown"  href="index.php?option=com_users&view=users"><span class="sidebar-item-title">Manage</span></a><span class="menu-quicktask"><a href="index.php?option=com_users&task=user.add"><span class="fa fa-plus" title="Add User" aria-hidden="true"></span><span class="sr-only">Add User</span></a></span></li>
					<li><a class="nav-link dropdown"  href="index.php?option=com_users&view=groups"><span class="sidebar-item-title">Groups</span></a></li>
					<li><a class="nav-link dropdown"  href="index.php?option=com_users&view=levels"><span class="sidebar-item-title">Access Levels</span></a></li>
					<li class="divider" role="presentation"><span></span></li>
					<li><a class="nav-link dropdown"  href="index.php?option=com_fields&view=fields&context=com_users.user"><span class="sidebar-item-title">Fields</span></a></li>
					<li><a class="nav-link dropdown"  href="index.php?option=com_fields&view=groups&context=com_users.user"><span class="sidebar-item-title">Field Groups</span></a></li>
					<li class="divider" role="presentation"><span></span></li>
					<li><a class="nav-link dropdown"  href="index.php?option=com_users&view=notes"><span class="sidebar-item-title">User Notes</span></a></li>
					<li><a class="nav-link dropdown"  href="index.php?option=com_categories&view=categories&extension=com_users"><span class="sidebar-item-title">User Note Categories</span></a></li>
					<li class="divider" role="presentation"><span></span></li>
					<li class="dropdown-submenu"><a class="nav-link dropdown has-arrow"  href="#"><span class="sidebar-item-title">Privacy</span></a><span class="menu-dashboard"><a href="/j4/administrator/index.php?option=com_cpanel&amp;view=cpanel&amp;dashboard=privacy"><span class="fa fa-th-large" title="MOD_TOPMENU_DASHBOARD_LINK" aria-hidden="true"></span><span class="sr-only">MOD_TOPMENU_DASHBOARD_LINK</span></a></span>
						<ul class="dropdown-menu">
							<li><a class="nav-link dropdown"  href="index.php?option=com_privacy&view=requests"><span class="sidebar-item-title">Requests</span></a></li>
							<li><a class="nav-link dropdown"  href="index.php?option=com_privacy&view=capabilities"><span class="sidebar-item-title">Capabilities</span></a></li>
							<li><a class="nav-link dropdown"  href="index.php?option=com_privacy&view=consents"><span class="sidebar-item-title">Consents</span></a></li>
						</ul>
					</li>
					<li><a class="nav-link dropdown"  href="index.php?option=com_actionlogs&view=actionlogs"><span class="sidebar-item-title">User Actions Log</span></a></li>
					<li class="divider" role="presentation"><span></span></li>
					<li><a class="nav-link dropdown"  href="index.php?option=com_users&view=mail"><span class="sidebar-item-title">Mass Mail Users</span></a></li>
				</ul>
			</li>
			<li><a class="nav-link dropdown"  href="index.php?option=com_cpanel&view=cpanel&dashboard=system"><span class="fa fa-wrench fa-fw" aria-hidden="true"></span><span class="sidebar-item-title">System</span></a></li>
			<li><a class="nav-link dropdown"  href="index.php?option=com_cpanel&view=cpanel&dashboard=help"><span class="fa fa-info-circle fa-fw" aria-hidden="true"></span><span class="sidebar-item-title">Help</span></a></li>
		</ul>
	</div>
</nav>
<?php endif; ?>
<?php if (true) {
$direction = $doc->direction === 'rtl' ? 'float-right' : '';
$class     = $enabled ? 'nav flex-column main-nav ' . $direction : 'nav flex-column main-nav disabled ' . $direction;

// Recurse through children of root node if they exist
if ($root->hasChildren())
{
	//<nav class="main-nav-container" aria-label="' . Text::_('MOD_TOPMENU_ARIA_MAIN_MENU') . '">';
	/*
	echo '<nav class="navbar navbar-expand-md navbar-inverse" style="overflow: visible; z-index: 2000;">' ."\n";
	echo '<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#topnavbar"' ."\n";
	echo ' aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">' ."\n";
	echo '<span class="fas fa-bars"></span>' ."\n";
	echo '</button>' ."\n";
	echo '<div class="collapse navbar-collapse" id="topnavbar">' ."\n";
	echo '<ul id="topmenu" class="sm sm-blue">' . "\n";
	*/
	echo '<nav class="navbar navbar-expand-md navbar-inverse" style="z-index:2000; overflow: visible;">
	<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#topmenu"
		aria-controls="topmenu" aria-expanded="false" aria-label="Toggle navigation">
		<span class="fas fa-bars"></span>
	</button>
	<div class="collapse navbar-collapse" id="topmenu">

		<ul class="nav navbar-nav mr-auto">
';
	// WARNING: Do not use direct 'include' or 'require' as it is important to isolate the scope for each call
	$menu->renderSubmenu(ModuleHelper::getLayoutPath('mod_topmenu', 'default_submenu'), $root);

	echo "</ul></div></nav>\n";
}
}?>