<?php
/**
 * @package     Joomla.Administrator
 * @subpackage  mod_menu
 *
 * @copyright   Copyright (C) 2005 - 2019 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

use Joomla\CMS\Helper\ModuleHelper;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;

$doc       = $app->getDocument();
$doc->addStyleSheet(JURI::root(true) . '/administrator/modules/mod_topmenu/smartmenus-1.1.0/css/sm-blue/sm-blue.css');

$doc->addScript(JURI::root(true) . '/administrator/modules/mod_topmenu/smartmenus-1.1.0/jquery.smartmenus.js');
$doc->addScript(JURI::root(true) . '/administrator/modules/mod_topmenu/smartmenus-1.1.0/addons/bootstrap-4/jquery.smartmenus.bootstrap-4.js');
$doc->addScript(JURI::root(true) . '/administrator/modules/mod_topmenu/smartmenus-1.1.0/addons/keyboard/jquery.smartmenus.keyboard.min.js');

$direction = $doc->direction === 'rtl' ? 'float-right' : '';
$class     = $enabled ? 'nav flex-column main-nav ' . $direction : 'nav flex-column main-nav disabled ' . $direction;

// Recurse through children of root node if they exist
if ($root->hasChildren())
{
	echo '<nav class="navbar navbar-expand-md navbar-inverse" style="z-index:1029; overflow: visible;">
	<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#topmenu"
		aria-controls="topmenu" aria-expanded="false" aria-label="Toggle navigation">
		<span class="fas fa-bars"></span>
	</button>
	<div class="collapse navbar-collapse" id="topmenu">

		<ul class="nav navbar-nav mr-auto">
';
	// WARNING: Do not use direct 'include' or 'require' as it is important to isolate the scope for each call
	$menu->renderSubmenu(ModuleHelper::getLayoutPath('mod_topmenu', 'default_submenu'), $root);

	echo "</ul></div></nav>\n";
}
